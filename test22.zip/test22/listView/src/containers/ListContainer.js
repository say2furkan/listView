import React, { useEffect } from 'react'
import { compose } from 'redux'
import { useDispatch, useSelector } from 'react-redux'
import "./styles/exampleContainer.style.css";

import {
  exampleDataSelector,
  fetchingSelector,
} from '../selectors/exampleSelector'

import { item } from '../actions'
import { LoadingAnimation } from '../components/LoadingAnimation'
import { WithErrors } from '../hocs/WithErrors'

const ListContainer = () => {
  const dispatch = useDispatch()
  const exampleData = useSelector(exampleDataSelector)
  const fetching = useSelector(fetchingSelector)


  const onTileClickHandlar = (e,id) =>{
    e.preventDefault();
  }

  useEffect(() => {
    dispatch(item.request())
  }, [dispatch])

  return fetching && !exampleData 
    ? <LoadingAnimation />
    : (
      <div>
        <h1>List View</h1>
        <br />
        <div className="row">
        <div className="card">
            <h4 className="card-header">
              List Data:
              </h4>
              <div className="card-wrapper">
        {exampleData && exampleData.map((item)=>(
          
            <div className="card-body" onClick={(e)=>onTileClickHandlar(e, item.id)}>
              <h4 className="card-title">
                {item.id}
              </h4>
              <p className="card-text">
                {item.title}
              </p>
              <p className="card-text">
                {item.userId}
              </p>
            </div>
          
        ))}
          
          </div>
          </div>
        </div>
      </div>
  )
}

export default compose(
  WithErrors,
)(ListContainer)
