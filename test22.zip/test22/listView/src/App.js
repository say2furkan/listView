import React from 'react'
import { Route, Switch } from 'react-router-dom'
import { ExampleComponent } from './components/ExampleComponent'
import ListContainer from './containers/ListContainer'

export const App = () => (
  <Switch>
    <Route exact path="/" component={ListContainer} />
    <Route exact path="/exampleComponent" component={ExampleComponent} />
  </Switch>
)
