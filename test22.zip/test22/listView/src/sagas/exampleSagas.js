// In case you need to use a selector
// import also select from redux-saga/effects
// and then simplie yield select(yourSelector())

import {
  put, call, takeLatest, all,
} from 'redux-saga/effects'
import axios from 'axios'

import { ITEM } from '../actions/types'

import { item } from '../actions'

function* handleGet() {
  try {
    const { data } = yield call(axios.get, 'https://jsonplaceholder.typicode.com/todos')
    yield put(item.success({ data }))
  } catch (e) {
    yield put(item.failure({ error: { ...e } }))
  }
}

// function* handleGetOne(action) {
//   try {
//     const { id } = action.payload
//     const { data } = yield call(axios.get, `https://jsonplaceholder.typicode.com/todos`)
//     yield put(item.success({ data }))
//   } catch (e) {
//     yield put(item.failure({ error: { ...e } }))
//   }
// }


function* watchExampleSagas() {
  yield all([
    takeLatest(ITEM.GET, handleGet),
   // takeLatest(ITEM.GET_ONE, handleGetOne),
  ])
}

export default watchExampleSagas
